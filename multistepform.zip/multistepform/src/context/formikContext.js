//initial contextvalue of formikContext

export const formikDefaultValues = {
    personalInfo: { name: '', email: '', phone: '', languages: [] },
    workExperience: [{}],
    education: [{}],
    skills: [{}],
  }